package service

import (
	"context"
	"fmt"
)

// LNDConfig encapsulates the node credentials required to connect to mainnet/testnet
type LNDConfig struct {
	Host         string
	MacaroonPath string
	TLSCertPath  string
}

// LightningClient is a minimal interface matching the lnrpc.LightningClient methods we use.
// In production, wire in a real lnrpc.LightningClient via gRPC. In dev/regtest we use
// the mock implementation below so the binary compiles and runs without a live LND node.
type LightningClient interface {
	AddInvoice(ctx context.Context, valueSats int64, memo string) (string, error)
}

// mockLightningClient returns deterministic fake invoices for demo / regtest use.
type mockLightningClient struct{}

func (m *mockLightningClient) AddInvoice(_ context.Context, _ int64, memo string) (string, error) {
	return fmt.Sprintf("lnbc10n1mockinvoice_%x_proof_of_life", []byte(memo)[:8]), nil
}

type LightningService struct {
	client LightningClient
}

// NewLightningService returns a LightningService. If config is empty or LND is unreachable
// it silently falls back to the mock client so the server stays functional.
func NewLightningService(config *LNDConfig) (*LightningService, error) {
	if config == nil || config.Host == "" {
		return &LightningService{client: &mockLightningClient{}}, nil
	}

	// TODO: Production gRPC dial:
	//   creds, _ := credentials.NewClientTLSFromFile(config.TLSCertPath, "")
	//   conn, err := grpc.Dial(config.Host, grpc.WithTransportCredentials(creds), withMacaroon(config.MacaroonPath))
	//   return &LightningService{client: lnrpcAdapter{lnrpc.NewLightningClient(conn)}}, nil
	//
	// For now, fall back to mock so regtest demos work without a live LND.
	return &LightningService{client: &mockLightningClient{}}, nil
}

// GenerateProofInvoice creates a 1-sat invoice bound to a vault check-in proof.
func (l *LightningService) GenerateProofInvoice(ctx context.Context, vaultID string) (string, error) {
	memo := "Continuum Proof of Life | Vault: " + vaultID
	return l.client.AddInvoice(ctx, 1, memo)
}
